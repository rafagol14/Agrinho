# Ideias de Design - Site Agrinho 2026

## Resposta Selecionada: Design Sustentável com Raízes Naturais

### Design Movement
**Organic Modernism** - Uma fusão entre modernismo limpo e elementos naturais, inspirado na sustentabilidade e na conexão com a terra. Evita o minimalismo frio, abraçando texturas, formas orgânicas e uma paleta terrosa que remete ao agronegócio.

### Core Principles

1. **Autenticidade Agrícola**: O design deve comunicar a realidade do campo - não é abstrato, é concreto e tangível. Cada elemento visual deve contar uma história sobre sustentabilidade real.

2. **Acessibilidade Radical**: Não apenas acessibilidade técnica, mas visual. Cores contrastantes, tipografia clara, espaçamento generoso. O site deve ser usável por todos, incluindo pessoas cegas através de narração por IA.

3. **Movimento Orgânico**: Animações suaves que simulam crescimento e fluxo natural - não mecânicas ou abruptas. Elementos que "respiram" na página.

4. **Hierarquia Clara**: Informação estruturada em camadas, permitindo que o usuário navegue do macro (tema geral) para o micro (detalhes específicos) sem confusão.

### Color Philosophy

**Paleta Principal:**
- **Verde Profundo** (#2D5016): Raiz, estabilidade, floresta. Representa a preservação ambiental.
- **Terra Queimada** (#C85A2D): Calor, energia, o solo fértil. Representa a produção agrícola.
- **Creme Natural** (#F5F1E8): Fundo neutro, respeitoso, como papel artesanal.
- **Branco Puro** (#FFFFFF): Clareza, transparência.
- **Cinza Escuro** (#3A3A3A): Texto principal, profissionalismo.

**Raciocínio Emocional**: A combinação de verde e terra queimada cria tensão visual que representa o "equilíbrio" do tema - não é uma paleta harmoniosa demais (que sugeriria que tudo está resolvido), mas sim uma que mostra a necessidade de trabalho e dedicação.

### Layout Paradigm

**Assimétrico com Blocos Flutuantes**: Evita grids centrados. Usa blocos de conteúdo que "flutuam" em diferentes posições, criando dinamismo. Seções alternam entre texto à esquerda/imagem à direita e vice-versa.

**Estrutura em Camadas**:
- **Topo**: Hero section com imagem de campo e chamada para ação
- **Seções Temáticas**: Cada prática sustentável em um bloco visual distinto
- **Jogo Interativo**: Seção destacada com fundo diferente
- **Rodapé**: Informações sobre o Agrinho e links úteis

### Signature Elements

1. **Folhas Decorativas**: Pequenas ilustrações de folhas em diferentes pontos da página, criando um padrão visual que remete à natureza sem ser óbvio.

2. **Linhas Orgânicas Divisoras**: Em vez de linhas retas, usar SVG com curvas suaves que simulam raízes ou rios, dividindo seções.

3. **Cards com Sombra Suave**: Cada card de informação tem uma sombra morna (não fria), criando profundidade sem rigidez.

### Interaction Philosophy

- **Hover States Significativos**: Quando o usuário passa o mouse sobre um elemento, ele "cresce" ligeiramente e a sombra aumenta, como se estivesse ganho vida.
- **Cliques Responsivos**: Botões têm feedback tátil visual (escala 0.98 ao clicar).
- **Narração por IA**: Cada seção pode ser narrada. Ícone de som discreto que ativa/desativa a narração.

### Animation

- **Entrada de Elementos**: Elementos entram com fade + slide suave (300ms ease-out) quando a página carrega.
- **Scroll Animations**: Conforme o usuário rola, elementos aparecem gradualmente, criando sensação de descoberta.
- **Transições Suaves**: Todas as transições usam `cubic-bezier(0.23, 1, 0.32, 1)` para movimento snappy mas natural.
- **Respiração**: Elementos sutis como ícones têm uma animação de "respiração" leve (escala 1 → 1.05 → 1) em loop infinito.

### Typography System

**Display Font**: Playfair Display (serif, elegante, remete a tradição)
- Títulos principais (H1): 48px, weight 700
- Subtítulos (H2): 32px, weight 600

**Body Font**: Inter (sans-serif, legível, moderno)
- Corpo de texto: 16px, weight 400
- Ênfase: 16px, weight 600
- Pequeno: 14px, weight 400

**Hierarquia de Cores**:
- Títulos: Verde Profundo
- Subtítulos: Terra Queimada
- Corpo: Cinza Escuro
- Links: Verde Profundo com underline ao hover

---

## Decisão de Design

**Escolhido: Organic Modernism com paleta verde-terra e layout assimétrico.**

Este design comunica a seriedade do tema (sustentabilidade) sem ser entediante, mantém acessibilidade radical em primeiro plano, e cria uma experiência visual que remete ao mundo agrícola real. A narração por IA é integrada como feature nativa, não como afterthought.
