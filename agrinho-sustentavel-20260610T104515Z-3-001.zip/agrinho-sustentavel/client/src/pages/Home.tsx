import { useEffect } from 'react';

export default function Home() {
  useEffect(() => {
    // Inicializar o jogo quando a página carrega
    initGame();
    
    // Sistema de Fala
    const speechToggle = document.getElementById('speechToggle');
    if (speechToggle) {
      speechToggle.addEventListener('click', toggleSpeech);
    }

    // Adicionar narração a seções
    document.querySelectorAll('section').forEach(section => {
      section.addEventListener('click', function(e: any) {
        if (e.target.tagName === 'BUTTON' || e.target.tagName === 'A') return;
        const text = this.innerText.substring(0, 500);
        speak(text);
      });
    });

    return () => {
      speechToggle?.removeEventListener('click', toggleSpeech);
    };
  }, []);

  const gameQuestions = [
    {
      question: "Qual é o principal benefício do plantio direto?",
      options: [
        { text: "Aumenta matéria orgânica e sequestra carbono", correct: true },
        { text: "Reduz o custo de sementes", correct: false },
        { text: "Elimina todas as pragas", correct: false },
        { text: "Aumenta a necessidade de água", correct: false }
      ]
    },
    {
      question: "O que é Integração Lavoura-Pecuária-Floresta (ILPF)?",
      options: [
        { text: "Combina agricultura, pecuária e florestamento na mesma área", correct: true },
        { text: "Usa apenas uma cultura por propriedade", correct: false },
        { text: "Elimina a necessidade de fertilizantes", correct: false },
        { text: "Reduz a produção de alimentos", correct: false }
      ]
    },
    {
      question: "Qual prática ajuda a fixar nitrogênio naturalmente no solo?",
      options: [
        { text: "Plantas de cobertura como crotalária", correct: true },
        { text: "Monocultura contínua", correct: false },
        { text: "Queimada de resíduos", correct: false },
        { text: "Revolvimento constante do solo", correct: false }
      ]
    },
    {
      question: "O que significa o Manejo 4Cs de fertilizantes?",
      options: [
        { text: "Fonte, dose, época e local corretos", correct: true },
        { text: "Usar 4 tipos diferentes de fertilizantes", correct: false },
        { text: "Aplicar fertilizante 4 vezes por ano", correct: false },
        { text: "Usar apenas fertilizantes químicos", correct: false }
      ]
    },
    {
      question: "Como o Manejo Integrado de Pragas (MIP) ajuda a sustentabilidade?",
      options: [
        { text: "Reduz uso de defensivos através de monitoramento e controle biológico", correct: true },
        { text: "Elimina todas as pragas permanentemente", correct: false },
        { text: "Aumenta a quantidade de agrotóxicos", correct: false },
        { text: "Não tem relação com sustentabilidade", correct: false }
      ]
    },
    {
      question: "Qual é a importância da análise periódica de solos?",
      options: [
        { text: "Identificar deficiências nutricionais e manter fertilidade", correct: true },
        { text: "Aumentar o preço dos produtos", correct: false },
        { text: "Reduzir a produção", correct: false },
        { text: "Eliminar a necessidade de adubação", correct: false }
      ]
    },
    {
      question: "Como você pode ajudar produtores rurais sustentáveis?",
      options: [
        { text: "Comprar produtos locais e de produtores sustentáveis", correct: true },
        { text: "Ignorar a origem dos produtos", correct: false },
        { text: "Comprar apenas produtos importados", correct: false },
        { text: "Não consumir alimentos agrícolas", correct: false }
      ]
    },
    {
      question: "Qual é o maior reservatório de carbono do planeta?",
      options: [
        { text: "O solo", correct: true },
        { text: "A atmosfera", correct: false },
        { text: "Os oceanos", correct: false },
        { text: "As florestas", correct: false }
      ]
    },
    {
      question: "O desmatamento ilegal é considerado crime?",
      options: [
        { text: "Sim, é crime ambiental com penas severas", correct: true },
        { text: "Não, é apenas uma infração leve", correct: false },
        { text: "Depende da quantidade de árvores", correct: false },
        { text: "Não é regulado por lei", correct: false }
      ]
    },
    {
      question: "Qual é um dos principais impactos do desmatamento?",
      options: [
        { text: "Perda de biodiversidade, mudanças climáticas e erosão do solo", correct: true },
        { text: "Aumento de chuvas", correct: false },
        { text: "Melhora da qualidade do ar", correct: false },
        { text: "Redução de enchentes", correct: false }
      ]
    },
    {
      question: "Como você pode ajudar a combater o desmatamento?",
      options: [
        { text: "Consumir produtos certificados e denunciar desmatamento ilegal", correct: true },
        { text: "Ignorar o problema", correct: false },
        { text: "Comprar produtos de origem duvidosa", correct: false },
        { text: "Não fazer nada", correct: false }
      ]
    },
    {
      question: "Qual lei brasileira protege as florestas?",
      options: [
        { text: "Código Florestal e Lei de Crimes Ambientais", correct: true },
        { text: "Não existe lei de proteção", correct: false },
        { text: "Apenas leis municipais", correct: false },
        { text: "Leis que permitem desmatamento", correct: false }
      ]
    }
  ];

  let currentQuestion = 0;
  let score = 0;
  let answered = false;
  let isSpeechEnabled = false;

  const speechSynthesis = window.speechSynthesis;

  function speak(text: string) {
    if (!isSpeechEnabled) return;
    
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'pt-BR';
    utterance.rate = 0.9;
    speechSynthesis.speak(utterance);
  }

  function toggleSpeech() {
    isSpeechEnabled = !isSpeechEnabled;
    const indicator = document.getElementById('speechIndicator');
    const text = document.getElementById('speechText');
    
    if (isSpeechEnabled) {
      indicator?.classList.remove('inactive');
      if (text) text.textContent = '🔊 Narração Ativa';
      speak('Narração ativada. Clique em qualquer seção para ouvir o conteúdo.');
    } else {
      indicator?.classList.add('inactive');
      if (text) text.textContent = '🔊 Narração';
      speechSynthesis.cancel();
    }
  }

  function initGame() {
    currentQuestion = 0;
    score = 0;
    answered = false;
    const gameResult = document.getElementById('gameResult');
    if (gameResult) gameResult.classList.remove('show');
    renderQuestion();
  }

  function renderQuestion() {
    const question = gameQuestions[currentQuestion];
    const gameContent = document.getElementById('gameContent');
    
    if (!gameContent) return;

    let html = `
      <div class="question active">
        <h3>Pergunta ${currentQuestion + 1} de ${gameQuestions.length}</h3>
        <p style="font-size: 1.1rem; margin-bottom: 1.5rem;">${question.question}</p>
        <div class="options">
    `;
    
    question.options.forEach((option, index) => {
      html += `
        <div class="option" onclick="window.selectOption(${index})" role="button" tabindex="0" aria-label="${option.text}">
          ${option.text}
        </div>
      `;
    });
    
    html += `</div></div>`;
    gameContent.innerHTML = html;
    
    const progress = ((currentQuestion + 1) / gameQuestions.length) * 100;
    const progressFill = document.getElementById('progressFill');
    if (progressFill) progressFill.style.width = progress + '%';
    
    speak(question.question);
  }

  function selectOption(index: number) {
    if (answered) return;
    
    answered = true;
    const question = gameQuestions[currentQuestion];
    const options = document.querySelectorAll('.option');
    
    options[index].classList.add(question.options[index].correct ? 'correct' : 'incorrect');
    
    if (question.options[index].correct) {
      score++;
      speak('Correto!');
    } else {
      speak('Incorreto. A resposta correta é: ' + question.options.find(o => o.correct)?.text);
    }
    
    if (!question.options[index].correct) {
      const correctIndex = question.options.findIndex(o => o.correct);
      options[correctIndex].classList.add('correct');
    }
    
    setTimeout(nextQuestion, 3000);
  }

  function nextQuestion() {
    currentQuestion++;
    answered = false;
    
    if (currentQuestion < gameQuestions.length) {
      renderQuestion();
    } else {
      endGame();
    }
  }

  function endGame() {
    const percentage = (score / gameQuestions.length) * 100;
    let message = '';
    
    if (percentage === 100) {
      message = `Parabéns! Você acertou todas as ${gameQuestions.length} perguntas! 🎉`;
    } else if (percentage >= 80) {
      message = `Excelente! Você acertou ${score} de ${gameQuestions.length} perguntas! 🌟`;
    } else if (percentage >= 60) {
      message = `Bom trabalho! Você acertou ${score} de ${gameQuestions.length} perguntas. Continue aprendendo! 📚`;
    } else {
      message = `Você acertou ${score} de ${gameQuestions.length} perguntas. Revise os temas e tente novamente! 💪`;
    }
    
    const resultText = document.getElementById('resultText');
    if (resultText) resultText.textContent = message;
    const gameResult = document.getElementById('gameResult');
    if (gameResult) gameResult.classList.add('show');
    speak(message);
  }

  function restartGame() {
    initGame();
  }

  // Expor funções globalmente
  (window as any).selectOption = selectOption;
  (window as any).restartGame = restartGame;

  return (
    <>
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        :root {
          --verde-profundo: #2D5016;
          --terra-queimada: #C85A2D;
          --creme-natural: #F5F1E8;
          --branco-puro: #FFFFFF;
          --cinza-escuro: #3A3A3A;
          --cinza-claro: #E8E8E8;
          --verde-claro: #4A7C3F;
          --terra-clara: #E8B4A0;
          --vermelho-alerta: #D32F2F;
          --vermelho-claro: #FFEBEE;
        }

        html {
          scroll-behavior: smooth;
        }

        body {
          font-family: 'Inter', sans-serif;
          background-color: var(--creme-natural);
          color: var(--cinza-escuro);
          line-height: 1.6;
          overflow-x: hidden;
        }

        h1, h2, h3 {
          font-family: 'Playfair Display', serif;
          font-weight: 700;
          line-height: 1.2;
        }

        h1 {
          font-size: 3rem;
          color: var(--verde-profundo);
          margin-bottom: 1rem;
        }

        h2 {
          font-size: 2.2rem;
          color: var(--verde-profundo);
          margin-bottom: 1.5rem;
        }

        h3 {
          font-size: 1.5rem;
          color: var(--terra-queimada);
          margin-bottom: 0.8rem;
        }

        p {
          font-size: 1rem;
          margin-bottom: 1rem;
          color: var(--cinza-escuro);
        }

        .container {
          max-width: 1200px;
          margin: 0 auto;
          padding: 0 2rem;
        }

        header {
          background-color: var(--branco-puro);
          box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
          position: sticky;
          top: 0;
          z-index: 100;
        }

        nav {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 1.5rem 2rem;
          max-width: 1200px;
          margin: 0 auto;
        }

        .logo {
          font-family: 'Playfair Display', serif;
          font-size: 1.8rem;
          font-weight: 700;
          color: var(--verde-profundo);
          text-decoration: none;
        }

        nav ul {
          display: flex;
          list-style: none;
          gap: 2rem;
          align-items: center;
          flex-wrap: wrap;
          justify-content: center;
        }

        nav a {
          text-decoration: none;
          color: var(--cinza-escuro);
          font-weight: 500;
          transition: color 0.3s ease;
          font-size: 0.95rem;
        }

        nav a:hover {
          color: var(--terra-queimada);
        }

        .speech-toggle {
          background-color: var(--verde-profundo);
          color: var(--branco-puro);
          border: none;
          padding: 0.7rem 1.2rem;
          border-radius: 0.5rem;
          cursor: pointer;
          font-weight: 600;
          transition: all 0.3s ease;
          display: flex;
          align-items: center;
          gap: 0.5rem;
          white-space: nowrap;
        }

        .speech-toggle:hover {
          background-color: var(--verde-claro);
          transform: scale(1.05);
        }

        .speech-toggle:active {
          transform: scale(0.98);
        }

        .hero {
          background: linear-gradient(135deg, var(--verde-profundo) 0%, var(--verde-claro) 100%);
          color: var(--branco-puro);
          padding: 6rem 2rem;
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        .hero::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600"><defs><pattern id="leaves" x="0" y="0" width="200" height="200" patternUnits="userSpaceOnUse"><path d="M50,50 Q75,30 100,50 Q75,70 50,50" fill="rgba(255,255,255,0.05)"/></pattern></defs><rect width="1200" height="600" fill="url(%23leaves)"/></svg>');
          opacity: 0.3;
        }

        .hero-content {
          position: relative;
          z-index: 1;
          max-width: 800px;
          margin: 0 auto;
          animation: fadeInUp 0.8s ease-out;
        }

        .hero h1 {
          color: var(--branco-puro);
          font-size: 3.5rem;
          margin-bottom: 1rem;
        }

        .hero p {
          color: rgba(255, 255, 255, 0.95);
          font-size: 1.2rem;
          margin-bottom: 2rem;
        }

        .cta-button {
          background-color: var(--terra-queimada);
          color: var(--branco-puro);
          border: none;
          padding: 1rem 2rem;
          font-size: 1.1rem;
          border-radius: 0.5rem;
          cursor: pointer;
          font-weight: 600;
          transition: all 0.3s ease;
          display: inline-block;
          text-decoration: none;
        }

        .cta-button:hover {
          background-color: #B84A1F;
          transform: translateY(-2px);
          box-shadow: 0 10px 20px rgba(200, 90, 45, 0.3);
        }

        .cta-button:active {
          transform: scale(0.98);
        }

        section {
          padding: 5rem 2rem;
          animation: fadeInUp 0.8s ease-out;
        }

        .section-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 3rem;
          align-items: center;
          max-width: 1200px;
          margin: 0 auto;
        }

        .section-content.reverse {
          direction: rtl;
        }

        .section-content.reverse > * {
          direction: ltr;
        }

        .section-text h2 {
          margin-bottom: 1.5rem;
        }

        .section-text h3 {
          margin-top: 1.5rem;
          margin-bottom: 0.8rem;
        }

        .section-text p {
          margin-bottom: 1rem;
          line-height: 1.8;
        }

        .section-visual {
          background: linear-gradient(135deg, var(--terra-clara) 0%, var(--creme-natural) 100%);
          padding: 3rem;
          border-radius: 1rem;
          box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
          min-height: 300px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 4rem;
          text-align: center;
        }

        .section-visual.alert {
          background: linear-gradient(135deg, var(--vermelho-claro) 0%, #FFCDD2 100%);
        }

        .cards-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
          gap: 2rem;
          max-width: 1200px;
          margin: 0 auto;
        }

        .card {
          background: var(--branco-puro);
          padding: 2rem;
          border-radius: 1rem;
          box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
          transition: all 0.3s ease;
          cursor: pointer;
        }

        .card:hover {
          transform: translateY(-5px);
          box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        .card h3 {
          margin-bottom: 1rem;
        }

        .card-icon {
          font-size: 3rem;
          margin-bottom: 1rem;
        }

        .card.alert {
          border-left: 5px solid var(--vermelho-alerta);
        }

        .card.alert h3 {
          color: var(--vermelho-alerta);
        }

        .game-section {
          background: linear-gradient(135deg, var(--terra-queimada) 0%, #A84620 100%);
          color: var(--branco-puro);
          padding: 4rem 2rem;
        }

        .game-container {
          max-width: 800px;
          margin: 0 auto;
          background: rgba(255, 255, 255, 0.1);
          padding: 3rem;
          border-radius: 1rem;
          backdrop-filter: blur(10px);
        }

        .game-container h2 {
          color: var(--branco-puro);
          margin-bottom: 2rem;
          text-align: center;
        }

        .question {
          margin-bottom: 2rem;
          display: none;
        }

        .question.active {
          display: block;
          animation: fadeInUp 0.5s ease-out;
        }

        .question h3 {
          color: var(--branco-puro);
          margin-bottom: 1.5rem;
          font-size: 1.3rem;
        }

        .options {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .option {
          background: rgba(255, 255, 255, 0.2);
          border: 2px solid rgba(255, 255, 255, 0.3);
          padding: 1rem;
          border-radius: 0.5rem;
          cursor: pointer;
          transition: all 0.3s ease;
          color: var(--branco-puro);
          font-weight: 500;
        }

        .option:hover {
          background: rgba(255, 255, 255, 0.3);
          border-color: rgba(255, 255, 255, 0.5);
        }

        .option.correct {
          background: #4CAF50;
          border-color: #45a049;
        }

        .option.incorrect {
          background: #f44336;
          border-color: #da190b;
        }

        .game-result {
          text-align: center;
          margin-top: 2rem;
          display: none;
        }

        .game-result.show {
          display: block;
        }

        .game-result h3 {
          color: var(--branco-puro);
          margin-bottom: 1rem;
        }

        .progress-bar {
          width: 100%;
          height: 8px;
          background: rgba(255, 255, 255, 0.2);
          border-radius: 4px;
          margin-bottom: 2rem;
          overflow: hidden;
        }

        .progress-fill {
          height: 100%;
          background: #4CAF50;
          transition: width 0.3s ease;
        }

        footer {
          background-color: var(--verde-profundo);
          color: var(--branco-puro);
          padding: 3rem 2rem;
          text-align: center;
        }

        footer p {
          color: rgba(255, 255, 255, 0.9);
          margin-bottom: 0.5rem;
        }

        .action-list {
          list-style: none;
          margin: 1.5rem 0;
        }

        .action-list li {
          padding: 0.8rem 0;
          padding-left: 2rem;
          position: relative;
          margin-bottom: 0.5rem;
        }

        .action-list li::before {
          content: '✓';
          position: absolute;
          left: 0;
          color: var(--verde-profundo);
          font-weight: bold;
          font-size: 1.2rem;
        }

        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        @keyframes breathe {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.05); }
        }

        .breathe {
          animation: breathe 3s ease-in-out infinite;
        }

        @media (max-width: 768px) {
          h1 { font-size: 2rem; }
          h2 { font-size: 1.5rem; }
          h3 { font-size: 1.2rem; }

          nav ul {
            gap: 0.5rem;
            font-size: 0.9rem;
          }

          .section-content {
            grid-template-columns: 1fr;
          }

          .section-content.reverse {
            direction: ltr;
          }

          .hero {
            padding: 3rem 1rem;
          }

          .hero h1 {
            font-size: 2rem;
          }
        }

        .sr-only {
          position: absolute;
          width: 1px;
          height: 1px;
          padding: 0;
          margin: -1px;
          overflow: hidden;
          clip: rect(0, 0, 0, 0);
          white-space: nowrap;
          border-width: 0;
        }

        .speech-indicator {
          display: inline-block;
          width: 12px;
          height: 12px;
          background-color: #4CAF50;
          border-radius: 50%;
          margin-right: 0.5rem;
          animation: pulse 1.5s ease-in-out infinite;
        }

        .speech-indicator.inactive {
          background-color: #ccc;
          animation: none;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
      `}</style>

      <header>
        <nav>
          <a href="#" className="logo">🌱 AgroForte</a>
          <ul>
            <li><a href="#sobre">Sobre</a></li>
            <li><a href="#praticas">Práticas</a></li>
            <li><a href="#ajudar">Ajudar</a></li>
            <li><a href="#desmatamento">Desmatamento</a></li>
            <li><a href="#jogo">Jogo</a></li>
            <li><button className="speech-toggle" id="speechToggle" aria-label="Ativar narração por voz">
              <span className="speech-indicator inactive" id="speechIndicator"></span>
              <span id="speechText">🔊 Narração</span>
            </button></li>
          </ul>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="hero-content">
            <h1>AgroForte: Futuro Sustentável</h1>
            <p>Descubra como equilibrar produção agrícola com preservação ambiental</p>
            <p style={{ fontSize: '0.9rem', marginTop: '1rem' }}>Concurso Agrinho 2026</p>
            <button className="cta-button" onClick={() => document.getElementById('sobre')?.scrollIntoView()}>Explorar Agora</button>
          </div>
        </section>

        <section id="sobre">
          <div className="container">
            <h2>Sobre o Agrinho 2026</h2>
            <div className="section-content">
              <div className="section-text">
                <p>O Concurso Agrinho 2026 traz o tema <strong>"Agro forte, futuro sustentável: equilíbrio entre produção e meio ambiente"</strong>.</p>
                <p>Este site foi criado para ajudar estudantes e agropecuários a entender como é possível produzir alimentos de forma sustentável, preservando o planeta para as futuras gerações.</p>
                <p>Aqui você aprenderá sobre práticas sustentáveis, como ajudar produtores rurais, os perigos do desmatamento ilegal e poderá testar seus conhecimentos em nosso jogo interativo.</p>
              </div>
              <div className="section-visual">📚</div>
            </div>
          </div>
        </section>

        <section id="praticas" style={{ backgroundColor: 'var(--branco-puro)' }}>
          <div className="container">
            <h2>Práticas Sustentáveis na Agropecuária</h2>
            <div className="cards-grid">
              <div className="card">
                <div className="card-icon">🌾</div>
                <h3>Plantio Direto</h3>
                <p>Não revolve o solo, mantendo a palhada após colheita. Aumenta matéria orgânica, sequestra carbono e reduz erosão.</p>
              </div>
              <div className="card">
                <div className="card-icon">🌿</div>
                <h3>Plantas de Cobertura</h3>
                <p>Cultiva plantas como braquiária e crotalária para proteger o solo, fixar nitrogênio e combater pragas naturalmente.</p>
              </div>
              <div className="card">
                <div className="card-icon">🌲</div>
                <h3>Integração Lavoura-Pecuária-Floresta</h3>
                <p>Combina agricultura, pecuária e florestamento na mesma área, otimizando uso de terra e reduzindo emissões.</p>
              </div>
              <div className="card">
                <div className="card-icon">🧪</div>
                <h3>Análise de Solos</h3>
                <p>Análise periódica e correção de solos mantém a fertilidade e evita degradação do ambiente produtivo.</p>
              </div>
              <div className="card">
                <div className="card-icon">⚖️</div>
                <h3>Manejo 4Cs</h3>
                <p>Fonte, dose, época e local corretos para aplicação de fertilizantes, minimizando impacto ambiental.</p>
              </div>
              <div className="card">
                <div className="card-icon">🐛</div>
                <h3>Manejo Integrado de Pragas</h3>
                <p>Monitoramento intensivo e controle biológico reduzem uso de defensivos químicos mantendo produtividade.</p>
              </div>
            </div>
          </div>
        </section>

        <section id="ajudar" style={{ backgroundColor: 'var(--terra-clara)' }}>
          <div className="container">
            <h2>Como Você Pode Ajudar os Agropecuários</h2>
            <div className="section-content reverse">
              <div className="section-text">
                <h3>🛒 Consumo Consciente</h3>
                <p>Compre produtos de produtores locais e sustentáveis. Seu apoio financeiro ajuda a manter práticas responsáveis e gera renda para as famílias rurais.</p>
                
                <h3>💰 Apoio Financeiro e Técnico</h3>
                <p>Políticas públicas como PRONAF oferecem crédito para pequenos produtores investirem em tecnologias sustentáveis. Você pode apoiar essas iniciativas através de votação e participação em políticas públicas.</p>
                
                <h3>📚 Educação e Conscientização</h3>
                <p>Compartilhe conhecimento sobre sustentabilidade. Quanto mais pessoas entendem a importância, mais mudanças positivas acontecem nas comunidades rurais.</p>
                
                <h3>🤝 Apoio Comunitário</h3>
                <p>Participe de programas de agricultura familiar, cooperativas e associações. Seu envolvimento fortalece a organização dos produtores.</p>
                
                <h3>♻️ Certificação e Rastreabilidade</h3>
                <p>Procure por produtos certificados como orgânicos, Fair Trade ou com selos de sustentabilidade. Isso garante que o produtor está sendo recompensado justamente.</p>
              </div>
              <div className="section-visual">❤️</div>
            </div>
          </div>
        </section>

        <section id="desmatamento" style={{ backgroundColor: 'var(--vermelho-claro)' }}>
          <div className="container">
            <h2 style={{ color: 'var(--vermelho-alerta)' }}>⚠️ Desmatamento Ilegal: Um Crime Ambiental</h2>
            <div className="section-content">
              <div className="section-text">
                <h3 style={{ color: 'var(--vermelho-alerta)' }}>O que é Desmatamento Ilegal?</h3>
                <p>É a remoção não autorizada de árvores e vegetação nativa, violando leis ambientais. É considerado crime ambiental no Brasil e em muitos países.</p>
                
                <h3 style={{ color: 'var(--vermelho-alerta)' }}>Impactos do Desmatamento</h3>
                <ul className="action-list">
                  <li><strong>Perda de Biodiversidade:</strong> Destruição de habitats de milhões de espécies</li>
                  <li><strong>Mudanças Climáticas:</strong> Redução de absorção de CO₂, aumentando aquecimento global</li>
                  <li><strong>Erosão do Solo:</strong> Perda de fertilidade e capacidade produtiva</li>
                  <li><strong>Secas e Enchentes:</strong> Alteração do ciclo hidrológico</li>
                  <li><strong>Impacto Social:</strong> Deslocamento de comunidades indígenas e tradicionais</li>
                </ul>
                
                <h3 style={{ color: 'var(--vermelho-alerta)' }}>Leis que Protegem as Florestas</h3>
                <p><strong>Código Florestal Brasileiro (Lei 12.651/2012):</strong> Exige preservação de áreas florestais e reservas legais.</p>
                <p><strong>Lei de Crimes Ambientais (Lei 9.605/1998):</strong> Prevê multas e prisão para desmatamento ilegal.</p>
              </div>
              <div className="section-visual alert">🚫</div>
            </div>

            <div style={{ marginTop: '3rem' }}>
              <h3 style={{ color: 'var(--vermelho-alerta)', marginBottom: '1.5rem' }}>Como Combater o Desmatamento?</h3>
              <div className="cards-grid">
                <div className="card alert">
                  <div className="card-icon">📱</div>
                  <h3>Denuncie Crimes Ambientais</h3>
                  <p>Reporte desmatamento ilegal para órgãos como IBAMA, Polícia Federal ou Ministério Público. Sua denúncia pode salvar florestas!</p>
                </div>
                <div className="card alert">
                  <div className="card-icon">🛍️</div>
                  <h3>Consumo Responsável</h3>
                  <p>Compre produtos certificados que não contribuem para desmatamento. Evite produtos de origem duvidosa.</p>
                </div>
                <div className="card alert">
                  <div className="card-icon">🌍</div>
                  <h3>Apoie Conservação</h3>
                  <p>Contribua para organizações que protegem florestas e apoiam comunidades indígenas.</p>
                </div>
                <div className="card alert">
                  <div className="card-icon">📢</div>
                  <h3>Conscientize</h3>
                  <p>Compartilhe informações sobre a importância das florestas e os perigos do desmatamento.</p>
                </div>
                <div className="card alert">
                  <div className="card-icon">🗳️</div>
                  <h3>Participe Politicamente</h3>
                  <p>Vote em candidatos que defendem políticas ambientais fortes e proteção florestal.</p>
                </div>
                <div className="card alert">
                  <div className="card-icon">📚</div>
                  <h3>Educação</h3>
                  <p>Estude e compartilhe conhecimento sobre ecossistemas, biodiversidade e sustentabilidade.</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section id="jogo" className="game-section">
          <div className="game-container">
            <h2>Teste Seus Conhecimentos!</h2>
            <p style={{ textAlign: 'center', marginBottom: '1.5rem', opacity: 0.9 }}>Responda perguntas sobre sustentabilidade, práticas agrícolas e proteção ambiental</p>
            <div className="progress-bar">
              <div className="progress-fill" id="progressFill" style={{ width: '0%' }}></div>
            </div>
            <div id="gameContent"></div>
            <div className="game-result" id="gameResult">
              <h3 id="resultText"></h3>
              <button className="cta-button" onClick={() => restartGame()} style={{ backgroundColor: 'var(--verde-profundo)', marginTop: '1rem' }}>Jogar Novamente</button>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <p><strong>AgroForte: Futuro Sustentável</strong></p>
        <p>Concurso Agrinho 2026 - Tema: Equilíbrio entre Produção e Meio Ambiente</p>
        <p>Desenvolvido para promover educação sobre sustentabilidade, proteção ambiental e apoio aos agropecuários</p>
        <p style={{ marginTop: '1.5rem', fontSize: '0.9rem' }}>© 2026 - Todos os direitos reservados</p>
      </footer>
    </>
  );
}
